﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using VendMach.Scripts;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для AddDrinks.xaml
    /// </summary>
    public partial class AddDrinks : Page
    {
        bool imageUpdate = false;
        public AddDrinks()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Add();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if(btnAdd.IsEnabled == false)  
                FrameApp.frmObj.GoBack();
            else if (imageUpdate == true)
            {
                if (MessageBox.Show($"Изображение было изменено! Сохранить перед выходом?", "Внимение!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Add();
                    FrameApp.frmObj.GoBack();
                }
                else FrameApp.frmObj.GoBack();
            }
            else
            {
                if (MessageBox.Show($"Введенные данные не будут сохранены! Сохранить перед выходом?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Add();
                    FrameApp.frmObj.GoBack();
                }
                else FrameApp.frmObj.GoBack();
            }
        }

        public string GetPath()
        {
            var dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true)
            {
                return dialog.FileName;
            }
            return null;
        }

        public byte[] getPNGFromImageControl(BitmapImage imageC)
        {
            MemoryStream memStream = new MemoryStream();
            PngBitmapEncoder encoder = new PngBitmapEncoder();
            try
            {
                encoder.Frames.Add(BitmapFrame.Create(imageC));
                encoder.Save(memStream);
            }
            catch { }
            
            return memStream.ToArray();
        }

        private void brImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            string path = GetPath();
            if (path == null) return;
            var pic = File.ReadAllBytes(path);
            var image = new BitmapImage();
            using (var mem = new MemoryStream(pic))
            {
                mem.Position = 0;
                image.BeginInit();
                image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.UriSource = null;
                image.StreamSource = mem;
                image.EndInit();
            }
            image.Freeze();
            img.Source = image;

            brImage.BorderBrush = Brushes.Transparent;

            imageUpdate = true;
        }

        private void Add()
        {
            if (tbCount.Text == "" && tbCost.Text == "" && tbTitle.Text == "")
            {
                labError.Content = "Введите данные и попробуйте снова!";
                tbTitle.Focus();
            }
            else if (tbTitle.Text == "")
            {
                labError.Content = "Укажите название напитка!";
                tbTitle.Focus();
            }
            else if (tbCost.Text == "" || !decimal.TryParse(tbCost.Text, out _))
            {
                labError.Content = "Укажите цену напитка!";
                tbCost.Focus();
            }
            else if (tbCount.Text == "" || !int.TryParse(tbCount.Text, out _))
            {
                labError.Content = "Укажите количество напитка!";
                tbCount.Focus();
            }
            else if (getPNGFromImageControl(img.Source as BitmapImage).Length < 5)
            {
                labError.Content = "Загрузите изображение!";
            }
            else
            {
                labError.Content = "";
                try
                {
                    Drinks drinks = new Drinks()
                    {
                        Name = tbTitle.Text,
                        Image = getPNGFromImageControl(img.Source as BitmapImage),
                        Cost = decimal.Parse(tbCost.Text)
                    };
                    ConnectHelper.entObj.Drinks.Add(drinks);
                    ConnectHelper.entObj.SaveChanges();

                    var drinksID = ConnectHelper.entObj.Drinks.FirstOrDefault(x => x.Name == tbTitle.Text);

                    VendMachineDrinks vendMachineDrinks = new VendMachineDrinks()
                    {
                        VendMachId = 1,
                        DrinksId = drinksID.Id,
                        Count = int.Parse(tbCount.Text)
                    };
                    ConnectHelper.entObj.VendMachineDrinks.Add(vendMachineDrinks);
                    ConnectHelper.entObj.SaveChanges();
                    labError.Content = "Напиток успешно добавлен!";
                    btnAdd.IsEnabled = false;
                    imageUpdate = false;

                    var dim = ConnectHelper.entObj.DrinksInMach.FirstOrDefault(x => x.DrinksId == drinksID.Id);
                    MainWindow.countInStart.Add(dim);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message.ToString(), "Важно", MessageBoxButton.OK);
                }
            }
        }
    }
}
