﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Data;
using System.Windows.Controls;
using VendMach.Scripts;
using Excel = Microsoft.Office.Interop.Excel;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для Report.xaml
    /// </summary>
    public partial class Report : Page
    {
        public Report()
        {
            InitializeComponent();

            List<ReportHelper> reportHelpers = new List<ReportHelper>();
            int i = 0;
            foreach (DrinksInMach dim in ConnectHelper.entObj.DrinksInMach)
            {
                int countStart = MainWindow.countInStart[i].Count;
                reportHelpers.Add(new ReportHelper
                {
                    Name = dim.Name,
                    Cost = dim.Cost,
                    CountActual = dim.Count,
                    CountStart = countStart,
                    Profit = (countStart - dim.Count) * dim.Cost
                });
                i++;
            }
            tbDate.Text = DateTime.Today.ToString("dd.MM.yyyy");
            dgReport.ItemsSource = reportHelpers;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excel = new Excel.Application();
            excel.Visible = true; //www.yazilimkodlama.com
            Excel.Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
            Excel.Worksheet sheet1 = (Excel.Worksheet)workbook.Sheets[1];

            for (int j = 0; j < dgReport.Columns.Count; j++) // за титулы
            {
                Excel.Range myRange = (Excel.Range)sheet1.Cells[1, j + 1];
                sheet1.Cells[1, j + 1].Font.Bold = true; //чтобы заголовок был жирным шрифтом
                sheet1.Columns[j + 1].ColumnWidth = 15; // регулировка ширины столбца
                myRange.Value2 = dgReport.Columns[j].Header;
            }
            for (int i = 0; i < dgReport.Columns.Count; i++)
            { //www.yazilimkodlama.com
                for (int j = 0; j < dgReport.Items.Count; j++)
                {
                    TextBlock b = dgReport.Columns[i].GetCellContent(dgReport.Items[j]) as TextBlock;
                    Excel.Range myRange = (Excel.Range)sheet1.Cells[j + 2, i + 1];
                    myRange.Value2 = b.Text;
                }
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
