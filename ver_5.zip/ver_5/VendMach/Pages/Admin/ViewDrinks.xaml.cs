﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using VendMach.Scripts;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для ViewDrinks.xaml
    /// </summary>
    public partial class ViewDrinks : Page
    {
        public static int idDrink { get; set; }

        public ViewDrinks()
        {
            InitializeComponent();
        }
        //Список напитков
        List<DrinksInMach> dim = ConnectHelper.entObj.DrinksInMach.Where(d => d.VendMachId == 1).ToList();

        //При загрузке приложения загружает с БД и выводит на экран картинки и данные по напиткам
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            dim = ConnectHelper.entObj.DrinksInMach.Where(d => d.VendMachId == 1).ToList();
            spDrinks.Children.Clear();
            Label lbPlus = new Label
            {
                Content = "+",
                FontSize = 40,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            //Рамка и вставление туда панельки напитка
            Border border2 = new Border
            {
                BorderBrush = Brushes.Black,
                BorderThickness = new Thickness(2),
                Margin = new Thickness(5),
                Width = 125,
                Height = 220,
                Child = lbPlus,
                Background = Brushes.Transparent,
                CornerRadius = new CornerRadius(10)
            };

            //добавление метода выделения напитка
            border2.MouseLeftButtonDown += new MouseButtonEventHandler(selectDrinks_Click);

            //добавление элементов
            spDrinks.Children.Add(border2);

            //Вывод (перебор) товаров на экран
            foreach (DrinksInMach drink in dim)
            {
                //создание картинки
                byte[] imageData = drink.Image;
                var image = new BitmapImage();
                using (var mem = new MemoryStream(imageData))
                {
                    mem.Position = 0;
                    image.BeginInit();
                    image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.UriSource = null;
                    image.StreamSource = mem;
                    image.EndInit();
                }
                image.Freeze();

                //Панелька напитка
                StackPanel spMicro = new StackPanel { Orientation = Orientation.Vertical };

                //код напитка
                Label lb = new Label
                {
                    Content = drink.DrinksId,
                    Visibility = Visibility.Hidden,
                    Width = 0,
                    Height = 0,
                };

                //добавление картинки
                spMicro.Children.Add(new Image { Source = image });

                // название и цена
                spMicro.Children.Add(new TextBlock
                {
                    Text = $"{drink.Name}\n{drink.Cost}р.",
                    HorizontalAlignment = HorizontalAlignment.Center,
                    TextAlignment = TextAlignment.Center,
                    FontWeight = FontWeights.Bold
                });

                //Рамка и вставление туда панельки напитка
                Border border = new Border
                {
                    BorderBrush = Brushes.Green,
                    BorderThickness = new Thickness(2),
                    Child = spMicro,
                    Margin = new Thickness(5),
                    Width = 125,
                    Background = Brushes.Transparent,
                    CornerRadius = new CornerRadius(10)
                };

                //добавление метода выделения напитка
                border.MouseLeftButtonDown += new MouseButtonEventHandler(selectDrinks_Click);

                //добавление элементов
                spDrinks.Children.Add(border);
                spMicro.Children.Add(lb);
            }
        }

        bool selectDrinks = false;

        //Метод выбора нипитка
        private void selectDrinks_Click(object sender, MouseButtonEventArgs e)
        {
            //если не выбрано 
            if (!selectDrinks)
            {
                (sender as Border).Background = Brushes.LightSteelBlue;
                selectDrinks = true;

                if((sender as Border).BorderBrush == Brushes.Black)
                {
                    //Если выбрано "да"
                    if (MessageBox.Show($"Вы выбрали Добавление нового напитка. Добавить напиток?", "Запрос на добавление.", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        (sender as Border).BorderBrush = Brushes.Black;
                        (sender as Border).Background = Brushes.Transparent;
                        selectDrinks = false;
                        FrameApp.frmObj.Navigate(new AddDrinks());
                    }
                    //если "нет" тогда делаем обводку зелёной и снимаем выделение
                    else
                    {
                        (sender as Border).BorderBrush = Brushes.Black;
                        (sender as Border).Background = Brushes.Transparent;
                        selectDrinks = false;
                    }
                }
                else
                {
                    //код напитка из скрытой метки
                    int b = int.Parse((((sender as Border).Child as StackPanel).Children[2] as Label).Content.ToString());

                    //название напитка
                    string a = ConnectHelper.entObj.Drinks.Where(d => d.Id == b).First().Name;

                    //Если выбрано "да"
                    if (MessageBox.Show($"Вы выбрали {a}. Изменить данный напиток?", "Запрос на редактрирование.", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        (sender as Border).BorderBrush = Brushes.Green;
                        (sender as Border).Background = Brushes.Transparent;
                        selectDrinks = false;

                        idDrink = b;

                        FrameApp.frmObj.Navigate(new UpdateDrinks());
                    }
                    //если "нет" тогда делаем обводку зелёной и снимаем выделение
                    else
                    {
                        (sender as Border).BorderBrush = Brushes.Green;
                        (sender as Border).Background = Brushes.Transparent;
                        selectDrinks = false;
                    }
                }
            }
            //Если выбрано то убрать выделение 
            else if ((sender as Border).BorderBrush == Brushes.Blue && selectDrinks)
            {
                (sender as Border).BorderBrush = Brushes.Green;
                (sender as Border).Background = Brushes.Transparent;
                selectDrinks = false;
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
