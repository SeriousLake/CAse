﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendMach.Scripts
{
    class ConnectHelper
    {
        public static VendMachEntities entObj;
    }
}
