﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendMach.Scripts
{
    public class ReportHelper
    {
        public string Name { get; set; }
        public decimal Cost { get; set; }
        public int CountStart { get; set; }
        public int CountActual { get; set; }
        public decimal Profit { get; set; }
    }
}
